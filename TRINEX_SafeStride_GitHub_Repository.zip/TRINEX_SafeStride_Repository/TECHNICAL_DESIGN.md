# SafeStride Technical Design

## 1. Purpose
This document describes a software simulation of the SafeStride emergency-alert flow for a student prototype.

## 2. System flow
1. A double-tap event is simulated by running the program.
2. The program obtains configured demo coordinates.
3. It validates that latitude is between -90 and 90 and longitude is between -180 and 180.
4. It creates a timestamped SOS event.
5. It prints simulated alert, buzzer, and LED statuses.
6. It appends the event to a local JSON file.

## 3. Components

| Component | Prototype implementation | Future hardware implementation |
|---|---|---|
| Trigger | Program run simulates double-tap | Touch/double-tap sensor + microcontroller |
| Location | Sample coordinates / environment variables | GPS module |
| SOS | JSON event record; no message sent | GSM/LTE module sends SMS to consented contacts |
| Buzzer | Console status only | Buzzer driven by suitable circuit |
| LED | Console status only | LED indicator |
| Storage | Local JSON file | Local storage and/or secure app backend |

## 4. Environment variables
- `SAFESTRIDE_LAT`: demo latitude
- `SAFESTRIDE_LON`: demo longitude
- `SAFESTRIDE_CONTACT`: demo contact label (not a phone number)
- `SAFESTRIDE_OUTPUT`: output file path

If no location variables are set, the program uses `sample_data/demo_location.json`.

## 5. Data format
An alert includes:
- `event_id`: unique identifier
- `timestamp_utc`: UTC timestamp
- `event_type`: `SOS`
- `status`: `SIMULATED`
- `location`: latitude and longitude
- `contact_label`: intended recipient label
- `indicators`: simulated buzzer and LED states

## 6. Privacy and safety
- Use fake/demo coordinates in public demonstrations.
- Do not store private phone numbers, API tokens, or real user location in this public repository.
- This simulation does not deliver real emergency alerts and is not a certified medical or personal safety product.
- A physical prototype needs hardware review, battery safety checks, waterproofing tests, and repeated field tests.

## 7. Test strategy
Automated unit tests validate coordinate boundaries, alert fields, and invalid coordinate rejection. Hardware and SMS tests are out of scope for this software-only prototype.
